<?php defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

if (!function_exists('success')) {
    function success($messages)
    {
        $alert = "
    <script>
    Swal.fire({
			title: 'Sukses !!!',
			text: '" . $messages . "',
			type: 'success',
			backdrop: 'rgba(0,0,0,.4)'
		})
    </script>
		";
        return $alert;
    }
}

if (!function_exists('error')) {
    function error($messages)
    {
        $alert = "
    <script>
    Swal.fire({
			title: 'Gagal !!!',
			text: '" . $messages . "',
			type: 'error',
			backdrop: 'rgba(0,0,0,.4)'
		})
    </script>
		";
        return $alert;
    }
}

if (!function_exists('info')) {
    function information($messages)
    {
        $alert = "
    <script>
    Swal.fire({
            title: 'Oopss !!!',
            text: '" . $messages . "',
            type: 'info',
            backdrop: 'rgba(0,0,0,.4)'
        })
    </script>
        ";
        return $alert;
    }
}

function cek_data_payment($trx, $bank, $haystack, $strict = false)
{
    foreach ($haystack as $item) {
        // $item     = get_object_vars($item);
        if (($strict ? $item->jenis_trx === $trx : $item->jenis_trx == $trx) && ($strict ? $item->kode_bank === $bank : $item->kode_bank == $bank)) {
            return true;
        }
    }

    // for ($i=0; $i < count($haystack); $i++) {

    //   if (($strict ? $haystack[$i]['kode_bank'] === $trx : $haystack[$i]['kode_bank'] == $trx)) {
    //   // if (($strict ? $haystack[$i]['kode_bank'] === $trx : $haystack[$i]['kode_bank'] == $trx) || (is_array($haystack) && cek_array($trx,$key, $haystack, $strict))) {
    //         return true;
    //         break;
    //   }
    // }

    return false;
}

function ucapan()
{
    date_default_timezone_set("Asia/Jakarta");

    $b = time();
    $hour = date("G", $b);

    if ($hour >= 0 && $hour <= 11) {
        echo "Selamat Pagi :)";
    } elseif ($hour >= 12 && $hour <= 14) {
        echo "Selamat Siang :) ";
    } elseif ($hour >= 15 && $hour <= 17) {
        echo "Selamat Sore :) ";
    } elseif ($hour >= 17 && $hour <= 18) {
        echo "Selamat Petang :) ";
    } elseif ($hour >= 19 && $hour <= 23) {
        echo "Selamat Malam :) ";
    }
}
