<?php
defined('BASEPATH') or exit('No direct script access allowed');

function is_logged_in()
{
	$ci = &get_instance();
	$user = $ci->session->userdata('token');
	if (!isset($user)) {
		redirect('');
	} else {
		return true;
	}
}

function is_logged_in_admin()
{
	$ci = &get_instance();
	$user = $ci->session->userdata('Admintoken');
	if (!isset($user)) {
		redirect('');
	} else {
		return true;
	}
}
function UrlApi()
{
	// $link = 'http://147.139.182.75:3753/api/';
	// $link = 'http://192.168.4.92:3753/api/';
	$link = 'http://54.151.162.118:3753/api/';
	return $link;
}

function detect_mobile()
{
	if (preg_match('/(alcatel|amoi|android|avantgo|blackberry|benq|cell|cricket|docomo|elaine|htc|iemobile|iphone|ipad|ipaq|ipod|j2me|java|midp|mini|mmp|mobi|motorola|nec-|nokia|palm|panasonic|philips|phone|playbook|sagem|sharp|sie-|silk|smartphone|sony|symbian|t-mobile|telus|up.browser|up.link|vodafone|wap|webos|wireless|xda|xoom|zte)/i', $_SERVER['HTTP_USER_AGENT']))
		return true;
	else
		return false;
}


function cek_internet()
{
	$connected = @fsockopen("147.139.182.75", 3753);
	if ($connected) {
		$is_conn = "true"; //jika koneksi tersambung
		fclose($connected);
	} else {
		$is_conn = "false"; //jika koneksi gagal
	}
	return $is_conn;
}

function check_file_exists_here($url)
{
	$result = get_headers($url);
	$rs = stripos($result[0], "200 OK") ? "true" : "false"; //check if $result[0] has 200 OK
	if ($rs == "true") {
		return $url;
	} else {
		return base_url('/assets/notfound.png');
	}
}
