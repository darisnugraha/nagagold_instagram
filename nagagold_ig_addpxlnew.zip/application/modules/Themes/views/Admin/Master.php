<?php 
echo $_header;
echo $_content;
echo $_footer;
?>